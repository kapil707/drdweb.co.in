<div class="row">
    <div class="col-xs-12" style="margin-bottom:5px;">
    	<!-- <a href="add">
            <button type="submit" class="btn btn-info">
                Add
            </button>
        </a> -->
    </div>
	<div class="col-xs-12">
		<div class="row">
			<div class="col-md-3">
				<label for="date-range">Select Date Range:</label>
				<input type="text" id="date-range" class="form-control">
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12  pt-1 pb-5">
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover" id="example-table">
						<thead>
							<tr>
								<th>
									Sno.
								</th>
								<th>
									Sender
								</th>
								<th>
									Message
								</th>
								<th>
									Date
								</th>
								<th>
									Time
								</th>
								<th>
									ChemistID
								</th>
							</tr>
						</thead>
						
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
