<div class="row">
    <div class="col-xs-12" style="margin-bottom:5px;">
    	<!-- <a href="add">
            <button type="submit" class="btn btn-info">
                Add
            </button>
        </a> -->
   	</div>
	<div class="col-xs-12">
        <div class="table-responsive">
			<table class="table table-striped table-bordered table-hover" id="example-table">
                <thead>
                    <tr>
						<th>
							Value
						</th>
						<th>
							Chemist
						</th>
						<th>
                        	Edit
                        </th>
                    </tr>
                </thead>
				<tbody>
				</tbody>
			</table>
		</div>
    </div>
</div>