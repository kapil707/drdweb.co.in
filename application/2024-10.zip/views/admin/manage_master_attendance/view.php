<div class="row">
    <div class="col-xs-12" style="margin-bottom:5px;">
    	<?php /*<a href="add">
            <button type="submit" class="btn btn-info">
                Add
            </button>
        </a> */ ?>
   	</div>
	<div class="col-xs-12">
        <div class="table-responsive">
			<table class="table table-striped table-bordered table-hover" id="example-table">
                <thead>
                    <tr>
						<th>
							Sno.
						</th>
						<th>
							User Code
						</th>
						<th>
							User Altercode
						</th>
						<th>
							Token Key
						</th>
						<th>
							Data/Time
						</th>
                    </tr>
                </thead>
				<tbody>
					
				</tbody>
			</table>
		</div>
    </div>
</div>