<style>
.menubtn1
{
	display:none;
}
.homepgsearch_w
{
	display:none;
}
.headertitle
{
    margin-top: 5px !important;
}
.home_page_search_div_box,.select_chemist
{
	display: inline-block;
}
.select_medicine,.home_page_search_div,.search_medicine_result,.clear_search_icon
{
	display: none;
}
@media screen and (max-width: 767px) {
	.homebtn_div
	{
		display:none;
	}
}
</style>
<script>
$(".headertitle").html("Search chemist");
function goBack() {
	window.location.href = "<?= base_url();?>home";
}
</script>
<div class="container maincontainercss">
	<div class="row">
		<div class="col-sm-3"></div>
		<div class="col-sm-7 col-12">
			<span class="select_chemist_result"></span>
		</div>
		<div class="col-sm-2"></div>
	</div>
</div>
<div class="background_blur" onclick="clear_search_icon()" style="display:none"></div>
<script>
function page_load()
{
	search_focus();
	clear_search_icon();
}
function search_focus()
{
	$(".select_chemist_result").hide();
	$('.select_chemist').focus();
}
function clear_search_icon()
{
	$(".select_chemist_result").html("");
	$(".select_chemist").val("");
	$('.select_chemist').focus();
	$(".clear_search_icon").hide();
	$(".select_chemist_result").hide();	
	$(".background_blur").hide();
}
$(document).ready(function(){	
	$(".select_chemist").keyup(function() { 
		var keyword = $(".select_chemist").val();
		if(keyword!="")
		{
			if(keyword.length<3)
			{
				$('.select_chemist').focus();
				$(".select_chemist_result").html("");
			}
			search_chemist()
		}
		else{
			clear_search_icon();
		}
	});
	$(".select_chemist").change(function() { 
	});
	$(".select_chemist").on("search", function() { 
	});
	
    $(".select_chemist").keydown(function(event) {
    	if(event.key=="ArrowDown")
    	{
			page_up_down_arrow("1");
    		$('.hover_1').attr("tabindex",-1).focus();
			return false;
    	}
    });
	setTimeout('page_load();',100);
	
	document.onkeydown = function(evt) {
		evt = evt || window.event;
		if (evt.keyCode == 27) {
			clear_search_icon();
		}
	};
});
function search_chemist()
{
		new_i = 0;
		$(".clear_search_icon").show();
        var keyword = $(".select_chemist").val();
		if(keyword!="")
		{
			if(keyword.length>1)
			{
				$(".background_blur").show();
				$(".select_chemist_result").show();
				$(".select_chemist_result").html('<div class="row p-2" style="background:white;"><div class="col-sm-12 text-center"><h1><img src="<?= base_url(); ?>/img_v<?= constant('site_v') ?>/loading.gif" width="100px"></h1><h1>Loading....</h1></div></div>');
				$.ajax({
					type       : "POST",
					data       :  { keyword : keyword} ,
					url        : "<?php echo base_url(); ?>Chemist_medicine/search_chemist_api",
					cache	   : false,
					error: function(){
						$(".select_chemist_result").html('<h1><img src="<?= base_url(); ?>img_v<?= constant('site_v') ?>/something_went_wrong.png" width="100%"></h1>');
					},
					success    : function(data){
						if(data.items=="")
						{
							$(".select_chemist_result").html('<h1><center><img src="<?= base_url(); ?>/img_v<?= constant('site_v') ?>/no_record_found.png" width="100%"></center></h1>');
						}
						else
						{
							$(".select_chemist_result").html("");
						}
						$.each(data.items, function(i,item){	
							if (item){
								id	 		= item.id;
								chemist_id	= item.chemist_id;
								
								new_i = parseInt(new_i) + 1;
								li_css = "";
								
								a_ = 'onclick=select_chemist("'+chemist_id+'")';
								csshover1 = 'hover_'+new_i;
								
								$(".select_chemist_result").append('<div class="cart_ki_main_div '+csshover1+' select_chemist_'+new_i+'" '+a_+'><div class="cart_ki_main_div1_1"><img src="'+item.user_image+'" style="width: 100%;" class="border rounded"></div><div class="cart_ki_main_div2_1"><div class="cart_chemist_name">'+item.user_name+'</div><div class="cart_chemist_code"> Code : '+item.chemist_id+'</div></div>');
							}
						});					
					}
				});
			}
		}
		else{
			$(".clear_search_icon").hide();
			$(".select_chemist_result").html("");
		}
}
function select_chemist(chemist_id)
{	
	window.location.href = "<?= base_url();?>import_order/?chemist_id="+chemist_id;
}
function page_up_down_arrow(new_i)
{
	$('.hover_'+new_i).keypress(function (e) {
		 if (e.which == 13) {
			$('.select_chemist_'+new_i).click();
		 } 						 
	 });
	$('.hover_'+new_i).keydown(function(event) {
		if(event.key=="ArrowDown")
		{
			new_i = parseInt(new_i) + 1;
			page_up_down_arrow(new_i);
			$('.hover_'+new_i).attr("tabindex",-1).focus();
			return false;
		}
		if(event.key=="ArrowUp")
		{
			if(parseInt(new_i)==1)
			{
				$('.SearchMedicine_search_box').focus();
			}
			else
			{
				new_i = parseInt(new_i) - 1;
				page_up_down_arrow(new_i);
				$('.hover_'+new_i).attr("tabindex",-1).focus();
			}
			return false;
		}
	});
}
</script>