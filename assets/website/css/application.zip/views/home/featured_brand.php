<style>
.menubtn1
{
	display:none;
}
.headertitle
{
    margin-top: 5px !important;
}
@media screen and (max-width: 767px) {
	.homebtn_div
	{
		display:none;
	}
}
</style>
<script>
$(".headertitle").html("Loading....");
function goBack() {
	window.location.href = "<?= base_url();?>home";
}
</script>
<div class="container maincontainercss">
	<div class="row">
		<div class="col-sm-12 col-12">
			<div class="row">
				<div class="col-sm-12 text-right" style="margin-bottom:5px;">
					<img src="<?= base_url() ?>/img_v<?= constant('site_v') ?>/sortline.png" width="25px;" onclick="show_sorting_div();" class="showbtn" alt>
					<img src="<?= base_url() ?>/img_v<?= constant('site_v') ?>/sortline.png" width="25px;" onclick="hide_sorting_div();" class="showbtn1" style="display:none;" alt>
				</div>
				<div class="col-sm-12 sorting_div text-right" style="margin-bottom:5px;display:none;">
					<span class="sort_atoz" onclick="sort_atoz();">Name A to Z |</span>
					<span class="sort_ztoa" onclick="sort_ztoa();" style="display:none;">Name Z to A |</span>
					<span class="sort_price" onclick="sort_price();">Price Low to High | </span>
					<span class="sort_price1" onclick="sort_price1();" style="display:none;">Price High to Low | </span>
					<span class="sort_margin" onclick="sort_margin();">Margin Low to High</span>
					<span class="sort_margin1" onclick="sort_margin1();" style="display:none;">Margin High to Low</span>
				</div>
			</div>
			<div class="row load_page"></div>
			<div class="row">
				<div class="col-sm-12 load_page_loading" style="margin-top:10px;">
				
				</div>
			</div>
		</div>
	</div>     
</div>
<input type="hidden" class="lastid1">
<script>
$(document).ready(function(){
	call_page("not");
});
function call_page_by_last_id()
{
	lastid1=$(".lastid1").val();
	call_page("not")
}
function call_page(orderby1)
{
	$(".load_page").html("");
	$(".load_page_loading").html('<h1><center><img src="<?= base_url(); ?>/img_v<?= constant('site_v') ?>/loading.gif" width="100px"></center></h1><h1><center>Loading....</center></h1>');
	$.ajax({
		type       : "POST",
		data       :  {compcode:'<?= $compcode; ?>',division:'<?= $division; ?>',orderby:orderby1},
		url        : "<?php echo base_url(); ?>Chemist_json/featured_brand_api",
		cache	   : false,
		error: function(){
			$(".load_page_loading").html('<h1><center><img src="<?= base_url(); ?>/img_v<?= constant('site_v') ?>/no_record_found.png" width="100%"></center></h1>');
		},
		success    : function(data){
			if(data.items=="")
			{
				$(".load_page_loading").html('<h1><center><img src="<?= base_url(); ?>/img_v<?= constant('site_v') ?>/no_record_found.png" width="100%"></center></h1>');
			}
			else
			{
				$(".load_page_loading").html("");
			}
			$.each(data.items, function(i,item){
				if (item){
					i_code				= item.i_code;			
					name 				= item.name;
					company 			= item.company;
					image 				= item.image;
					packing 			= item.packing;
					mrp 				= item.mrp;
					ptr					= item.ptr;
					price 				= item.price;
					qty 				= item.qty;
					scheme 				= item.scheme;
					batch_no 			= item.batch_no;
					expiry 				= item.expiry;
					med_date_time 		= item.med_date_time;
					featured 			= item.featured;
					margin 				= item.margin;
					misc_settings       = item.misc_settings;

					featuredicon = '';
					if(featured=="1" && qty!="0"){
						featuredicon = '<div class="cart_featured"><span class="cart_featured_1">Featured</span></div>';
					}

					new_right_part = '<div class="cart_margin home_cart_margin1"><span class="cart_margin_1">'+margin+'% Margin</span></div>';
					batchqty1 = '<span class="cart_out_of_stock_lbl_small">Out of stock</span>';
					if(qty=="0"){
						new_right_part = '<div class="cart_out_of_stock home_cart_out_of_stock1"><span class="cart_out_of_stock_1">Out of stock</span></div>';
					}
					
					image1 = featuredicon+new_right_part+'<img src="'+image+'" class="img-fluid img-responsive" style="border-radius: 5px;">';

					rete_div =  '<div class="cart_ki_main_div5 text-left mobile_off"><span class="cart_mrp">MRP : <i class="fa fa-inr" aria-hidden="true"></i> '+mrp+'/-</span></div><div class="cart_ki_main_div5 text-right mobile_off"><span class="cart_ptr">PTR : <i class="fa fa-inr" aria-hidden="true"></i> '+ptr+'/-</div><div class="text-center cart_landing_price mobile_off">~Price : <i class="fa fa-inr" aria-hidden="true"></i> '+mrp+'/-</div> <div class="cart_ki_main_div5 text-left mobile_show"><span class="cart_mrp">MRP : <i class="fa fa-inr" aria-hidden="true"></i> '+mrp+'/-</span></div><div class="cart_ki_main_div5 text-left mobile_show"><span class="cart_ptr">PTR : <i class="fa fa-inr" aria-hidden="true"></i> '+ptr+'/-</div><div class="text-left cart_landing_price mobile_show">~Price : <i class="fa fa-inr" aria-hidden="true"></i> '+price+'/-</div>';
					
					$(".load_page").append('<div class="col-sm-3 col-6 p-0 m-0 text-center"><div class="featured_brand_div" onClick="get_single_medicine_info('+i_code+')" style="cursor: pointer;" title="'+name+'">'+image1+'<div class="text-left text-capitalize cart_title home_cart_title">'+name+' <span class="cart_packing">('+packing+' Packing)</span></div><div class="text-left text-capitalize cart_company home_cart_company1">By '+company+'</div>'+rete_div+'</div></div>');

					$(".headertitle").html(company);
				}
			});
		},
		timeout: 10000
	});
}
</script>
<script>
function show_sorting_div()
{
	$(".showbtn").hide();	
	$(".showbtn1").show();
	$(".sorting_div").show();
}
function hide_sorting_div()
{
	$(".showbtn").show();	
	$(".showbtn1").hide();
	$(".sorting_div").hide();
}

function sort_atoz()
{
	$(".sort_atoz").hide();
	$(".sort_ztoa").show();	
	hide_sorting_div();
	call_page("sort_atoz");
}
function sort_ztoa()
{	
	$(".sort_atoz").show();
	$(".sort_ztoa").hide();
	hide_sorting_div();
	call_page("sort_ztoa");
}
function sort_price()
{
	$(".sort_price").hide();
	$(".sort_price1").show();	
	hide_sorting_div();
	call_page("sort_price");
}
function sort_price1()
{	
	$(".sort_price").show();
	$(".sort_price1").hide();
	hide_sorting_div();
	call_page("sort_price1");
}
function sort_margin()
{
	$(".sort_margin").hide();
	$(".sort_margin1").show();	
	hide_sorting_div();
	call_page("sort_margin");
}
function sort_margin1()
{	
	$(".sort_margin").show();
	$(".sort_margin1").hide();
	hide_sorting_div();
	call_page("sort_margin1");
}
</script>