<style>
.menubtn1
{
	display:none;
}
.headertitle
{
    margin-top: 5px !important;
}
</style>
<script>
$(".headertitle").html("Deleted items");
function goBack() {
	window.location.href = "<?= base_url();?>import_order";
}
</script>
<div class="container maincontainercss">
	<div class="row">
		<div class="col-sm-12 col-12">
			<div class="row">
				<div class="col-sm-12 col-12">
					<table class="table table-striped table-bordered" aria-describedby>
						<thead>
							<tr>
								<th style="width:50px;" scope>
									S.No.
								</th>
								<th scope>
									Item name
								</th>
								<th style="width:150px;" scope>
									Mrp.
								</th>
								<th style="width:150px;" scope>
									Quantity
								</th>
							</tr>
						</thead>
						<tbody>
						<?php
						$i = 1;
						foreach ($result as $row)
						{
							?>
							<tr>
								<td class="cart_id">
									<?= $i++ ?>
								</td>
								<td class="cart_title">
									<?= ucwords(strtolower($row->item_name)) ?>
								</td>
								<td class="cart_mrp">
									<?= $row->mrp ?>
								</td>
								<td class="cart_stock">
									<?= $row->quantity ?>
								</td>
							</tr>
							<?php
						}
						?>
						</tbody>
					</table>
				</div>
				<div class="col-sm-8 col-8 text-left">	
					<a href="<?= base_url(); ?>import_order/downloadfile/<?php echo base64_encode($order_id); ?>">
						<button type="submit" class="btn btn-primary mainbutton next_btn" name="submit" value="submit" style="width:35%">Download deleted items</button>
					</a>
				</div>
				<div class="col-sm-4 col-4 text-right">
					<a href="<?= base_url(); ?>home/draft_order_list/<?php echo ($chemist_id); ?>">
						<button type="submit" class="btn btn-primary mainbutton next_btn" name="submit" value="submit" style="width:20%">Next</button>
					</a>
				</div>
			</div>
		</div>
	</div>     
</div>