<style>
.headertitle1
{
	display: block !important;
}
.menubtn2,.homebtn_div
{
	display:none;
}
.headertitle
{
	font-size:13px;
	color:white;
}
</style>
<div class="container-fluid maincontainercss">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-12">		
			<div id="jssor_1">
			<!-- Loading Screen -->
				<div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
					<img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/spin.svg" alt>
				</div>
				<div data-u="slides" class="top_flash_div">
					<?php
					foreach($top_flash as $row)
					{
						if(empty($row["division"])){
							$row["division"]="not";
						}
						?>
						<div>
							<a href="javascript:callandroidfun('<?= $row["funtype"] ?>','<?= $row["itemid"] ?>','<?= base64_encode($row["compname"])?>','<?= $row["image"] ?>','<?= $row["division"] ?>');">
								<img src="<?= $row["image"] ?>" data-u="image" class="img_css_forslider" alt="" onerror="this.src='<?= base_url(); ?>/uploads/default_img.jpg'">
							</a>
						</div>
					<?php 
					} ?>
				</div>
				<!-- Bullet Navigator -->
				<div data-u="navigator" class="jssorb051" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
					<div data-u="prototype" class="i" style="width:16px;height:16px;">
						<svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
							<circle class="b" cx="8000" cy="8000" r="5800"></circle>
						</svg>
					</div>
				</div>
				<!-- Arrow Navigator -->
				<div data-u="arrowleft" class="jssora051" style="width:65px;height:65px;top:0px;left:35px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
					<svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
						<polyline class="a" points="11040,1920 4960,8000 11040,14080 "></polyline>
					</svg>
				</div>
				<div data-u="arrowright" class="jssora051" style="width:65px;height:65px;top:0px;right:35px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
					<svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
						<polyline class="a" points="4960,1920 11040,8000 4960,14080 "></polyline>
					</svg>
				</div>
			</div>
			<script type="text/javascript">jssor_1_slider_init();</script>
		</div>
				

		<div class="col-xs-12 col-sm-12 col-12">
			<?php if(!empty($result1)){?>
			<div class="featured_home_title">
				<h1 class="heading_home"><span><?php echo $title1; ?></span></h1>
			</div>
			<section class="featured_home" id="featured_home">
				<div class="swiper featured_home-slider featured-slider">
					<div class="swiper-wrapper">
						<?php
						foreach($result1 as $row)
						{
							if(empty($row["division"])){
								$row["division"] = "not";
							}
							?>
						<div class="swiper-slide box">
							<div class="mcs-items-container">
								<div class="home_main_div">
									<div class="image1">
										<a href="<?= base_url(); ?>home/featured_brand/<?= $row["compcode"]; ?>/<?= $row["division"]; ?>">
											<img src="<?= $row["image"]; ?>" alt="">
										</a>
									</div>
									<div class="content">
										<a href="<?= base_url(); ?>home/featured_brand/<?= $row["compcode"]; ?>/<?= $row["division"]; ?>">
											<div class="home_cart_company">
												<?= ($row["company_full_name"]); ?>
											</div>
										</a>
									</div>
								</div>
							</div>
						</div>
						<?php 
							}?>
					</div>
					<div class="swiper-button-next swiper-button-next1"></div>
					<div class="swiper-button-prev swiper-button-prev1"></div>
				</div>
			</section>
			<?php } ?>
		</div>

		<div class="col-xs-12 col-sm-12 col-12">
			<div class="featured_home_title">
				<h1 class="heading_home"><span>Menu</span></h1>
			</div>
		</div>
		
		<div class="col-xs-2 col-sm-2 col-4 p-1">
			<div class="home_menu_main_div">
				<a href="<?= base_url('home/search_medicine')?>" style="color:black">
					<div class="text-center">
						<img src="<?= base_url() ?>img_v<?= constant('site_v') ?>/homebtn1.png" class="img-fluid img-responsive" alt>
						<div class="home_menu_main_btn">New order</div>
					</div>
				</a>
			</div>
		</div>
		<div class="col-xs-2 col-sm-2 col-4 p-1">
			<div class="home_menu_main_div">
				<a href="<?= base_url('home/draft_order_list')?>"  style="color:black">
					<div class="text-center">
						<img src="<?= base_url() ?>img_v<?= constant('site_v') ?>/homebtn2.png" class="img-fluid img-responsive" alt>
						<div class="home_menu_main_btn">Draft <span class="mycartwalidiv1"></span></div>
					</div>
				</a>
			</div>
		</div>

		<div class="col-xs-2 col-sm-2 col-4 p-1">
			<div class="home_menu_main_div">
				<a href="<?= base_url('home/my_orders')?>" style="color:black" title="My orders">
					<div class="text-center">
						<img src="<?= base_url() ?>img_v<?= constant('site_v') ?>/homebtn3.png" class="img-fluid img-responsive" alt>
						<div class="home_menu_main_btn">My orders</div>
					</div>
				</a>
			</div>
		</div>
		
		<div class="col-xs-2 col-sm-2 col-4 p-1">
			<div class="home_menu_main_div">
				<a href="<?= base_url('home/my_invoice')?>" style="color:black" title="My invoices">
					<div class="text-center">
						<img src="<?= base_url() ?>img_v<?= constant('site_v') ?>/homebtn4.png" class="img-fluid img-responsive" alt>
						<div class="home_menu_main_btn">My invoices</div>
					</div>
				</a>
			</div>
		</div>
		
		<div class="col-xs-2 col-sm-2 col-4 p-1">
			<div class="home_menu_main_div">
				<a href="<?= base_url('home/track_order')?>" style="color:black" title="Track order">
					<div class="text-center">
						<img src="<?= base_url() ?>img_v<?= constant('site_v') ?>/homebtn5.png" class="img-fluid img-responsive" alt>
						<div class="home_menu_main_btn">Track order</div>
					</div>
				</a>
			</div>
		</div>
		
		<div class="col-xs-2 col-sm-2 col-4 p-1 mobile_off">
			<div class="home_menu_main_div">
				<a href="<?= base_url('import_order')?>" title="Upload order">
					<div class="text-center">
						<img src="<?= base_url()?>img_v<?= constant('site_v') ?>/homebtn6.png" class="img-fluid img-responsive" alt>
						<div class="home_menu_main_btn">Upload order</div>
					</div>
				</a>
			</div>
		</div>
		
		<div class="col-xs-2 col-sm-2 col-4 p-1 mobile_show">
			<div class="home_menu_main_div">
				<a href="<?= base_url('home/my_notification')?>" title="Notifications">
					<div class="text-center">
						<img src="<?= base_url() ?>img_v<?= constant('site_v') ?>/homebtn7.png" class="img-fluid img-responsive" alt>
						<div class="home_menu_main_btn">Notifications</div>
					</div>
				</a>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-12">
			<?php 
			if(!empty($result2)){?>
			<div class="featured_home_title">
				<h1 class="heading_home"><span><?php echo $title2; ?></span></h1>
			</div>
			<section class="featured_home" id="featured_home">
				<div class="swiper featured_home-slider featured-slider1">
					<div class="swiper-wrapper">
						<?php
						foreach($result3 as $row)
						{
							if(empty($_SESSION['user_session']))
							{
								$row["item_mrp"] 		= "xx.xx";
								$row["item_ptr"] 		= "xx.xx";
								$row["item_price"]		= "xx.xx";
								$row["item_margin"] 		= "xx";
							}
							$margin_div = '<div class="cart_margin home_cart_margin"><span class="cart_margin_1">'.$row["item_margin"].'% Margin</span></div>';
							$featuredicon = '';
							if($row["item_featured"]==1 && $row["item_quantity"]!=0) {
								$featuredicon = '<div class="cart_featured home_cart_featured"><span class="cart_featured_1">Featured</span></div>';
							}
							if($row["item_quantity"]==0) {
								$margin_div = '<div class="cart_out_of_stock home_cart_out_of_stock"><span class="cart_out_of_stock_1">Out of stock</span></div>';
							}
							?>
						<div class="swiper-slide box">
							<div class="mcs-items-container">
								<div class="home_main_div">
									<div class="image">
										<a href="javascript:void(0)" onClick="get_single_medicine_info('<?= $row["item_code"]; ?>')">
											<?php echo $featuredicon ?>
											<?php echo $margin_div ?>
											<img src="<?= $row["item_image"]; ?>" alt="" onerror="this.src='<?= base_url(); ?>/uploads/default_img.jpg'" class="medicine_cart_item_image">
										</a>
									</div>
									<div class="content">
										<a href="javascript:void(0)" onClick="get_single_medicine_info('<?= $row["item_code"]; ?>')">
											<div class="medicine_cart_item_name"><?= ($row["item_name"]); ?><span class="medicine_cart_item_packing">(<?= $row["item_packing"]; ?> Packing)</span></div>
											<div class="medicine_cart_item_company">By <?= ($row["item_company"]); ?></div>
											<div class="medicine_cart_item_mrp">MRP : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_mrp"]; ?>/-
											</div>
											<div class="medicine_cart_item_ptr">PTR : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_ptr"]; ?>/-
											</div>
											<div class="medicine_cart_item_price">~Price : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_price"]; ?>/-</div>
										</a>
									</div>
								</div>
							</div>
						</div>
						<?php  
							}
						?>
					</div>
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
				</div>
			</section>
			<?php } ?>
		</div>
		<div class="col-sm-12">
			<?php 
			if(!empty($result3)){?>
			<section class="featured_home" id="featured_home">
			<div class="featured_home_title">
				<h1 class="heading_home"><span><?php echo $title3; ?></span></h1>
			</div>
			<section class="featured_home" id="featured_home">
				<div class="swiper featured_home-slider featured-slider1">
					<div class="swiper-wrapper">
						<?php
						foreach($result3 as $row)
						{
							if(empty($_SESSION['user_session']))
							{
								$row["item_mrp"] 		= "xx.xx";
								$row["item_ptr"] 		= "xx.xx";
								$row["item_price"]		= "xx.xx";
								$row["item_margin"] 		= "xx";
							}
							$margin_div = '<div class="cart_margin home_cart_margin"><span class="cart_margin_1">'.$row["item_margin"].'% Margin</span></div>';
							$featuredicon = '';
							if($row["item_featured"]==1 && $row["item_quantity"]!=0) {
								$featuredicon = '<div class="cart_featured home_cart_featured"><span class="cart_featured_1">Featured</span></div>';
							}
							if($row["item_quantity"]==0) {
								$margin_div = '<div class="cart_out_of_stock home_cart_out_of_stock"><span class="cart_out_of_stock_1">Out of stock</span></div>';
							}
							?>
						<div class="swiper-slide box">
							<div class="mcs-items-container">
								<div class="home_main_div">
									<div class="image">
										<a href="javascript:void(0)" onClick="get_single_medicine_info('<?= $row["item_code"]; ?>')">
											<?php echo $featuredicon ?>
											<?php echo $margin_div ?>
											<img src="<?= $row["item_image"]; ?>" alt="" onerror="this.src='<?= base_url(); ?>/uploads/default_img.jpg'" class="medicine_cart_item_image">
										</a>
									</div>
									<div class="content">
										<a href="javascript:void(0)" onClick="get_single_medicine_info('<?= $row["item_code"]; ?>')">
											<div class="medicine_cart_item_name"><?= ($row["item_name"]); ?><span class="medicine_cart_item_packing">(<?= $row["item_packing"]; ?> Packing)</span></div>
											<div class="medicine_cart_item_company">By <?= ($row["item_company"]); ?></div>
											<div class="medicine_cart_item_mrp">MRP : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_mrp"]; ?>/-
											</div>
											<div class="medicine_cart_item_ptr">PTR : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_ptr"]; ?>/-
											</div>
											<div class="medicine_cart_item_price">~Price : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_price"]; ?>/-</div>
										</a>
									</div>
								</div>
							</div>
						</div>
						<?php  
							}
						?>
					</div>
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
				</div>
			</section>
			<?php } ?>
		</div>

		<div class="col-sm-12">
			<?php 
			if(!empty($result4)){?>
			<section class="featured_home" id="featured_home">
			<div class="featured_home_title">
				<h1 class="heading_home"><span><?php echo $title4; ?></span></h1>
			</div>
			<section class="featured_home" id="featured_home">
				<div class="swiper featured_home-slider featured-slider1">
					<div class="swiper-wrapper">
						<?php
						foreach($result3 as $row)
						{
							if(empty($_SESSION['user_session']))
							{
								$row["item_mrp"] 		= "xx.xx";
								$row["item_ptr"] 		= "xx.xx";
								$row["item_price"]		= "xx.xx";
								$row["item_margin"] 		= "xx";
							}
							$margin_div = '<div class="cart_margin home_cart_margin"><span class="cart_margin_1">'.$row["item_margin"].'% Margin</span></div>';
							$featuredicon = '';
							if($row["item_featured"]==1 && $row["item_quantity"]!=0) {
								$featuredicon = '<div class="cart_featured home_cart_featured"><span class="cart_featured_1">Featured</span></div>';
							}
							if($row["item_quantity"]==0) {
								$margin_div = '<div class="cart_out_of_stock home_cart_out_of_stock"><span class="cart_out_of_stock_1">Out of stock</span></div>';
							}
							?>
						<div class="swiper-slide box">
							<div class="mcs-items-container">
								<div class="home_main_div">
									<div class="image">
										<a href="javascript:void(0)" onClick="get_single_medicine_info('<?= $row["item_code"]; ?>')">
											<?php echo $featuredicon ?>
											<?php echo $margin_div ?>
											<img src="<?= $row["item_image"]; ?>" alt="" onerror="this.src='<?= base_url(); ?>/uploads/default_img.jpg'" class="medicine_cart_item_image">
										</a>
									</div>
									<div class="content">
										<a href="javascript:void(0)" onClick="get_single_medicine_info('<?= $row["item_code"]; ?>')">
											<div class="medicine_cart_item_name"><?= ($row["item_name"]); ?><span class="medicine_cart_item_packing">(<?= $row["item_packing"]; ?> Packing)</span></div>
											<div class="medicine_cart_item_company">By <?= ($row["item_company"]); ?></div>
											<div class="medicine_cart_item_mrp">MRP : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_mrp"]; ?>/-
											</div>
											<div class="medicine_cart_item_ptr">PTR : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_ptr"]; ?>/-
											</div>
											<div class="medicine_cart_item_price">~Price : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_price"]; ?>/-</div>
										</a>
									</div>
								</div>
							</div>
						</div>
						<?php  
							}
						?>
					</div>
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
				</div>
			</section>
			<?php } ?>
		</div>

		<div class="col-sm-12">
			<?php 
			if(!empty($result5)){?>
			<div class="featured_home_title">
				<h1 class="heading_home"><span><?php echo $title5; ?></span></h1>
			</div>
			<section class="featured_home" id="featured_home">
				<div class="swiper featured_home-slider featured-slider1">
					<div class="swiper-wrapper">
						<?php
						foreach($result3 as $row)
						{
							if(empty($_SESSION['user_session']))
							{
								$row["item_mrp"] 		= "xx.xx";
								$row["item_ptr"] 		= "xx.xx";
								$row["item_price"]		= "xx.xx";
								$row["item_margin"] 		= "xx";
							}
							$margin_div = '<div class="cart_margin home_cart_margin"><span class="cart_margin_1">'.$row["item_margin"].'% Margin</span></div>';
							$featuredicon = '';
							if($row["item_featured"]==1 && $row["item_quantity"]!=0) {
								$featuredicon = '<div class="cart_featured home_cart_featured"><span class="cart_featured_1">Featured</span></div>';
							}
							if($row["item_quantity"]==0) {
								$margin_div = '<div class="cart_out_of_stock home_cart_out_of_stock"><span class="cart_out_of_stock_1">Out of stock</span></div>';
							}
							?>
						<div class="swiper-slide box">
							<div class="mcs-items-container">
								<div class="home_main_div">
									<div class="image">
										<a href="javascript:void(0)" onClick="get_single_medicine_info('<?= $row["item_code"]; ?>')">
											<?php echo $featuredicon ?>
											<?php echo $margin_div ?>
											<img src="<?= $row["item_image"]; ?>" alt="" onerror="this.src='<?= base_url(); ?>/uploads/default_img.jpg'" class="medicine_cart_item_image">
										</a>
									</div>
									<div class="content">
										<a href="javascript:void(0)" onClick="get_single_medicine_info('<?= $row["item_code"]; ?>')">
											<div class="medicine_cart_item_name"><?= ($row["item_name"]); ?><span class="medicine_cart_item_packing">(<?= $row["item_packing"]; ?> Packing)</span></div>
											<div class="medicine_cart_item_company">By <?= ($row["item_company"]); ?></div>
											<div class="medicine_cart_item_mrp">MRP : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_mrp"]; ?>/-
											</div>
											<div class="medicine_cart_item_ptr">PTR : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_ptr"]; ?>/-
											</div>
											<div class="medicine_cart_item_price">~Price : <i class="fa fa-inr" aria-hidden="true"></i> <?= $row["item_price"]; ?>/-</div>
										</a>
									</div>
								</div>
							</div>
						</div>
						<?php  
							}
						?>
					</div>
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
				</div>
			</section>
			<?php } ?>
		</div>
	</div>

	<div class="row" style="margin-top:30px;">
		<div class="col-xs-12 col-sm-12 col-12 p-1">
			<div id="flash2" class="carousel slide" data-ride="carousel">
				<div class="carousel-inner">
				<?php
				foreach($top_flash2 as $row)
				{
					if(!empty($row["division"])){
						$row["division"]="not";
					}
					?>
					<div class="carousel-item <?= $row["id"] ?>">
						<a href="javascript:callandroidfun('<?= $row["funtype"] ?>','<?= $row["itemid"] ?>','<?= base64_encode($row["compname"])?>','<?= $row["image"] ?>','<?= $row["division"] ?>');">
							<img src="<?= $row["image"] ?>" class="" alt="" onerror="this.src='<?= base_url(); ?>/uploads/default_img.jpg'">
						</a>
					</div>
					<?php
				}
				?>
				</div>
				<a class="carousel-control-prev" href="#flash2" data-slide="prev">
					<span class="carousel-control-prev-icon"></span>
				</a>
				<a class="carousel-control-next" href="#flash2" data-slide="next">
					<span class="carousel-control-next-icon"></span>
				</a>
			</div>
		</div>
	</div>
</div>
<?php
$broadcast_status = $this->Scheme_Model->get_website_data("broadcast_status");
if($broadcast_status=="1"){ ?>
	<script>
	setTimeout(function() {
		$('.broadcast_title').html("<?= $this->Scheme_Model->get_website_data("broadcast_title"); ?>");
		$('.broadcast_message').html("<?= $this->Scheme_Model->get_website_data("broadcast_message"); ?>");
        $('.myModal_broadcast').click();
    }, 2000);
	</script>
	<?php
}
?>