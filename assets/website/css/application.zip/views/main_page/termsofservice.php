<style>
.menubtn1
{
	display:none;
}
.headertitle
{
    margin-top: 5px !important;
}
@media screen and (max-width: 767px) {
	.homebtn_div
	{
		display:none;
	}
}
</style>
<script>
$(".headertitle").html("Terms of services");
</script>
<div class="container maincontainercss">
	<div class="row">
		<div class="col-sm-12 col-12">
			<div class="row">
				<div class="col-sm-12 col-12 load_page">
				
				This site is owned and operated by  DR. Distributor here link is http://drdistributor.com/. Your privacy is of the utmost importance to us. At  DR. Distributor we want to make your online experience satisfying and safe.<br><br>

Because we gather certain types of information about our users, we feel you should fully understand our policy and the terms and conditions surrounding the capture and use of that information. This privacy statement discloses what information we gather and how we use it.<br><br>

  DR. DistributorProduct Outsourcing provides information on its website.  http://drdistributor.com/.   to the general public subject to the terms and conditions included in Section I of this Statement. By using the  DR. Distributor Product Outsourcing  Public Site, as defined below, you agree to be bound by the terms and conditions contained in Section I below.<br><br>

 DR. Distributor Product Outsourcing offers enhanced, special Website access to registered Members, who are required to agree to the additional terms & conditions contained in Section II below. The Section II terms and conditions apply only to Members<br><br>
				</div>
			</div>
		</div>
	</div>     
</div>